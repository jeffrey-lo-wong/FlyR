/**
 * Overview:
	
	The provided code is a Java program that represents the WelcomePage class. 
	It is the opening page that shows what the program is and can be sent to the HomePage
	
	Dependencies:
	1. Swing GUI library.

	Author:
	The application was developed by Jeffrey as a project for ICS4U1.

 */

package view;

//imports
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.basic.BasicButtonUI;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.RoundRectangle2D;

public class WelcomePage extends JFrame {

    private JPanel contentPane;

    public WelcomePage() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 500);

        contentPane = new JPanel();
        contentPane.setBackground(Color.WHITE);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Text area displaying the welcome message
        JTextArea txtrWelcomeToFlyr = new JTextArea();
        txtrWelcomeToFlyr.setBounds(55, 126, 407, 99);
        txtrWelcomeToFlyr.setFont(new Font("Heiti TC", Font.BOLD, 28));
        txtrWelcomeToFlyr.setText("Welcome to FlyR \nLet's head to your destination ");
        txtrWelcomeToFlyr.setEditable(false);

        // Button to start the application
        JButton btnNewButton = new JButton("Start");
        btnNewButton.setBounds(186, 249, 111, 48);
        btnNewButton.setForeground(Color.BLACK);
        btnNewButton.setFont(new Font("Heiti TC", Font.PLAIN, 13));

        // Set the custom button UI with the desired background color and rounded bounds
        btnNewButton.setUI(new BasicButtonUI() {
            @Override
            public void installDefaults(AbstractButton button) {
                super.installDefaults(button);
                button.setBackground(new ColorUIResource(0x47A0FF)); // Set the button background color
                button.setContentAreaFilled(false); // Remove the default button background
                button.setOpaque(true);
                button.setBorderPainted(false);
            }

            @Override
            protected void paintButtonPressed(Graphics g, AbstractButton b) {
                // Paint the button with the pressed state color
                if (b.isContentAreaFilled()) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setColor(new Color(0x0061B4));
                    g2.fill(new RoundRectangle2D.Double(0, 0, b.getWidth(), b.getHeight(), 50, 50)); 
                    g2.dispose();
                }
            }
        });

        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Start the main application frame
                setVisible(false);
                EventQueue.invokeLater(new Runnable() {
                    public void run() {
                        try {
                            HomePage frame = new HomePage();
                            frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
                            frame.setVisible(true);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
        });

        // Add components to the content pane
        contentPane.add(txtrWelcomeToFlyr);
        contentPane.add(btnNewButton);
    }
}
