/**
 * Overview:
	
	The provided code is a Java program that represents the HomePage class. 
	It allows users to input specific parameters related to their flight route and 
	displays the calculated steps of travel and a map with red dots representing 
	the user's location and destination.
	
	Note: The markers do not work as intended. They seem to be gone or really small
	
	Dependencies:
	1. Java Development Kit (JDK) 8 or higher.
	2. Swing GUI library.
	3. OpenSky API library.

	Author:
	The application was developed by Jeffrey as a project for ICS4U1.

 */

package view;

// imports
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import org.opensky.api.OpenSkyApi;

import controller.FlightRoutePlanner;
import model.Waypoint;

public class HomePage extends JFrame {

	private JPanel contentPane;
	private JTextField userLongitudeField;
	private JTextField userLatitudeField;
	private JTextField destLongitudeField;
	private JTextField destLatitudeField;
	private JTextField droneSpeedField;
	private JTextField safeDistanceField;
	private JTextArea outputArea;

	OpenSkyApi openSkyApi = new OpenSkyApi();

	/**
	 * Create the frame.
	 */
	public HomePage() {
		// Set up the frame
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(1920, 1080);

		// Set up the content pane and its layout
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		// Left panel
		JPanel leftPanel = new JPanel();
		leftPanel.setBackground(new Color(71, 160, 255));
		leftPanel.setBounds(0, 0, 640, 1080);
		contentPane.add(leftPanel);
		leftPanel.setLayout(null);

		// Title label
		JLabel lblTitle = new JLabel("FlyR");
		lblTitle.setFont(new Font("Heiti TC", Font.BOLD, 36));
		lblTitle.setForeground(Color.WHITE);
		lblTitle.setBounds(30, 30, 100, 40);
		leftPanel.add(lblTitle);

		// Subtext label
		JLabel lblSubtext = new JLabel("Please input the specifics below!");
		lblSubtext.setFont(new Font("Heiti TC", Font.PLAIN, 16));
		lblSubtext.setForeground(Color.WHITE);
		lblSubtext.setBounds(30, 80, 300, 20);
		leftPanel.add(lblSubtext);

		// Text field panel
		JPanel textFieldPanel1 = new JPanel();
		textFieldPanel1.setBackground(new Color(71, 160, 255));
		textFieldPanel1.setBounds(40, 102, 565, 500);
		leftPanel.add(textFieldPanel1);
		textFieldPanel1.setLayout(null);

		// User Longitude label
		JLabel lblUserLongitude = new JLabel("User Longitude:");
		lblUserLongitude.setFont(new Font("Heiti TC", Font.PLAIN, 16));
		lblUserLongitude.setForeground(Color.WHITE);
		lblUserLongitude.setBounds(10, 30, 150, 20);
		textFieldPanel1.add(lblUserLongitude);

		// User Longitude text field
		userLongitudeField = new JTextField();
		userLongitudeField.setBounds(10, 60, 549, 26);
		textFieldPanel1.add(userLongitudeField);
		userLongitudeField.setColumns(10);

		// User Latitude label
		JLabel lblUserLatitude = new JLabel("User Latitude:");
		lblUserLatitude.setFont(new Font("Heiti TC", Font.PLAIN, 16));
		lblUserLatitude.setForeground(Color.WHITE);
		lblUserLatitude.setBounds(10, 100, 150, 20);
		textFieldPanel1.add(lblUserLatitude);

		// User Latitude text field
		userLatitudeField = new JTextField();
		userLatitudeField.setBounds(10, 130, 549, 26);
		textFieldPanel1.add(userLatitudeField);
		userLatitudeField.setColumns(10);

		// Destination Longitude label
		JLabel lblDestLongitude = new JLabel("Destination Longitude:");
		lblDestLongitude.setFont(new Font("Heiti TC", Font.PLAIN, 16));
		lblDestLongitude.setForeground(Color.WHITE);
		lblDestLongitude.setBounds(10, 170, 180, 20);
		textFieldPanel1.add(lblDestLongitude);

		// Destination Longitude text field
		destLongitudeField = new JTextField();
		destLongitudeField.setBounds(10, 200, 549, 26);
		textFieldPanel1.add(destLongitudeField);
		destLongitudeField.setColumns(10);

		// Destination Latitude label
		JLabel lblDestLatitude = new JLabel("Destination Latitude:");
		lblDestLatitude.setFont(new Font("Heiti TC", Font.PLAIN, 16));
		lblDestLatitude.setForeground(Color.WHITE);
		lblDestLatitude.setBounds(10, 240, 180, 20);
		textFieldPanel1.add(lblDestLatitude);

		// Destination Latitude text field
		destLatitudeField = new JTextField();
		destLatitudeField.setBounds(10, 270, 549, 26);
		textFieldPanel1.add(destLatitudeField);
		destLatitudeField.setColumns(10);

		// Drone Speed label
		JLabel lblDroneSpeed = new JLabel("Drone Speed (m/s):");
		lblDroneSpeed.setFont(new Font("Heiti TC", Font.PLAIN, 16));
		lblDroneSpeed.setForeground(Color.WHITE);
		lblDroneSpeed.setBounds(10, 310, 180, 20);
		textFieldPanel1.add(lblDroneSpeed);

		// Drone Speed text field
		droneSpeedField = new JTextField();
		droneSpeedField.setBounds(10, 340, 549, 26);
		textFieldPanel1.add(droneSpeedField);
		droneSpeedField.setColumns(10);

		// Safe Distance label
		JLabel lblSafeDistance = new JLabel("Safe Distance (m):");
		lblSafeDistance.setFont(new Font("Heiti TC", Font.PLAIN, 16));
		lblSafeDistance.setForeground(Color.WHITE);
		lblSafeDistance.setBounds(10, 380, 180, 20);
		textFieldPanel1.add(lblSafeDistance);

		// Safe Distance text field
		safeDistanceField = new JTextField();
		safeDistanceField.setBounds(10, 410, 549, 26);
		textFieldPanel1.add(safeDistanceField);
		safeDistanceField.setColumns(10);

		// Submit button
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.setFont(new Font("Heiti TC", Font.PLAIN, 18));
		btnSubmit.setBounds(187, 454, 180, 46);
		textFieldPanel1.add(btnSubmit);
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Get input values
				double userLongitude = Double.parseDouble(userLongitudeField.getText());
				double userLatitude = Double.parseDouble(userLatitudeField.getText());
				double destLongitude = Double.parseDouble(destLongitudeField.getText());
				double destLatitude = Double.parseDouble(destLatitudeField.getText());
				double droneSpeed = Double.parseDouble(droneSpeedField.getText());
				double safeDistance = Double.parseDouble(safeDistanceField.getText());

				try {
					// Create an instance of FlightRoutePlanner
					FlightRoutePlanner routePlanner = new FlightRoutePlanner();

					// Get the safe route
					List<Waypoint> route = routePlanner.getSafeRoute(openSkyApi, userLongitude, userLatitude,
							destLongitude, destLatitude, droneSpeed, safeDistance);

					// Generate steps of travel
					String stepsOfTravel = generateStepsOfTravel(route);

					// Display the steps in the output area
					outputArea.setText(stepsOfTravel);

					// Update the map with red dots
					updateMapWithRedDots(userLongitude, userLatitude, destLongitude, destLatitude);
				} catch (IOException ex) {
					ex.printStackTrace();
				}
			}
		});

		// Output panel
		JPanel outputPanel = new JPanel();
		outputPanel.setBounds(30, 614, 580, 400);
		leftPanel.add(outputPanel);
		outputPanel.setLayout(null);

		// Output text area
		outputArea = new JTextArea();
		outputArea.setEditable(false);
		outputArea.setFont(new Font("Heiti TC", Font.PLAIN, 20));

		JScrollPane scrollPane = new JScrollPane(outputArea);
		scrollPane.setBounds(10, 10, 560, 380);
		outputPanel.add(scrollPane);

		// Right panel
		JPanel rightPanel = new JPanel();
		rightPanel.setBounds(640, 0, 1280, 1080);

		// Background image label
		JLabel backgroundLabel = new JLabel();
		backgroundLabel.setBounds(0, 0, 1280, 1080);
		rightPanel.add(backgroundLabel);

		// Load the image and set it as the icon for the label
		ImageIcon imageIcon = new ImageIcon("map.jpeg"); // Replace "map.jpg" with the actual image file path
		Image image = imageIcon.getImage().getScaledInstance(1280, 1080, Image.SCALE_DEFAULT);
		backgroundLabel.setIcon(new ImageIcon(image));

		contentPane.add(rightPanel);
	}

	private String generateStepsOfTravel(List<Waypoint> route) {
		StringBuilder steps = new StringBuilder();
		int stepCount = 1;

		// Start at the current location
		steps.append("Step ").append(stepCount++).append(": Start at current location\n");

		// Generate steps for each waypoint
		for (Waypoint waypoint : route) {
			String direction = waypoint.getDirection();
			double heading = waypoint.getHeading();
			double distance = waypoint.getDistance();
			double time = waypoint.getTime();

			steps.append("Step ").append(stepCount++).append(": Head ").append(direction).append(" (")
					.append(String.format("%.2f", heading)).append("°)").append(" for ")
					.append(String.format("%.2f", distance)).append("m for ").append(String.format("%.2f", time))
					.append(" seconds\n");
		}

		return steps.toString();
	}

	private void updateMapWithRedDots(double userLongitude, double userLatitude, double destLongitude,
			double destLatitude) {
		// Load the original map image
		ImageIcon imageIcon = new ImageIcon("map.jpeg"); // Replace "map.jpeg" with the actual image file path
		Image mapImage = imageIcon.getImage();

		// Create a BufferedImage object to draw on
		BufferedImage bufferedImage = new BufferedImage(mapImage.getWidth(null), mapImage.getHeight(null),
				BufferedImage.TYPE_INT_ARGB);

		// Get the Graphics2D object from the BufferedImage
		Graphics2D graphics = bufferedImage.createGraphics();

		// Draw the original map image onto the BufferedImage
		graphics.drawImage(mapImage, 0, 0, null);

		// Set the color to red
		graphics.setColor(Color.RED);

		// Draw a filled oval with a diameter of 10 pixels at the user's location
		int userX = convertLongitudeToX(userLongitude);
		int userY = convertLatitudeToY(userLatitude);
		graphics.fillOval(userX - 5, userY - 5, 10, 10);

		// Draw a filled oval with a diameter of 10 pixels at the destination
		int destX = convertLongitudeToX(destLongitude);
		int destY = convertLatitudeToY(destLatitude);
		graphics.fillOval(destX - 5, destY - 5, 10, 10);

		// Save the updated image to a file
		try {
			File outputFile = new File("updated_map.jpeg"); // Replace "updated_map.jpeg" with the desired file path
			ImageIO.write(bufferedImage, "jpeg", outputFile);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private int convertLongitudeToX(double longitude) {
		// Get the width of the map image
		int mapWidth = 1280;

		// Convert the longitude to a value between 0 and 1
		double normalizedLongitude = (longitude + 180) / 360;

		// Calculate the X-coordinate based on the normalized longitude
		int x = (int) (normalizedLongitude * mapWidth);

		return x;
	}

	private int convertLatitudeToY(double latitude) {
		// Get the height of the map image
		int mapHeight = 1080;

		// Convert the latitude to a value between 0 and 1
		double normalizedLatitude = (90 - latitude) / 180;

		// Calculate the Y-coordinate based on the normalized latitude
		int y = (int) (normalizedLatitude * mapHeight);

		return y;
	}
}
