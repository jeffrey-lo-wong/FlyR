/**
 * Overview:
	Gets the active data of planes to test the OpenSkyAPI
	
	Note: The application might require a live internet connection to retrieve aircraft data from the OpenSky API.

	Author:
	The FlyR Flight Route Planner application was developed by Jeffrey as a project for ICS4U1.

 */

package model;

import java.io.IOException;
import java.time.Instant;

import org.opensky.api.*;
import org.opensky.model.*;

public class FetchPlaneData {
	
	public static void main(String[] args) throws IOException {
		
		// Create an instance of the OpenSkyApi
		OpenSkyApi api = new OpenSkyApi();
		
		// Retrieve the states of all aircrafts
		OpenSkyStates os = api.getStates(0, null);

		if (os != null) {
		    // Iterate over each state vector and print the aircraft information
		    for (StateVector state : os.getStates()) {
		        System.out.println("ICAO24: " + state.getIcao24());
		        System.out.println("Callsign: " + state.getCallsign());
		        System.out.println("Origin Country: " + state.getOriginCountry());
		        System.out.println("Position: " + state.getLatitude() + ", " + state.getLongitude());
		        System.out.println("Altitude: " + state.getBaroAltitude() + " meters");
		        System.out.println("Velocity: " + state.getVelocity() + " m/s");
		        System.out.println("Vertical Rate: " + state.getVerticalRate() + " m/s");
		        System.out.println("=================================");
		    }
		} else {
		    System.out.println("No flight data available.");
		}
	}
}
