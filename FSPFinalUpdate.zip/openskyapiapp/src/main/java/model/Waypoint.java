/**
 * Overview:
	
	Waypoint class works to give the direction, heading, distance, and time
	
	Note: The markers do not work as intended. They seem to be gone or really small
	
	Dependencies:
	1. Java Development Kit (JDK) 8 or higher.
	2. Swing GUI library.
	3. OpenSky API library.

	Author:
	The application was developed by Jeffrey as a project for ICS4U1.

 */

package model;

public class Waypoint {
	
    private String direction; // Direction (north, south, east, west)
    private double heading; // Heading in degrees
    private double distance; // Distance to the waypoint in meters
    private double time; // Time to reach the waypoint in seconds

    public Waypoint(String direction, double heading, double distance, double time) {
        this.direction = direction;
        this.heading = heading;
        this.distance = distance;
        this.time = time;
    }

    
    // setters and getters
    public String getDirection() {
        return direction;
    }

    public double getHeading() {
        return heading;
    }

    public double getDistance() {
        return distance;
    }

    public double getTime() {
        return time;
    }
}
