/**
 * Overview:
	The FlightRoutePlanner is a Java application designed to help users plan safe flight routes based 
	on their current location and destination. It utilizes the OpenSky API to retrieve live aircraft data and 
	calculates a safe route by avoiding potential conflicts with other aircraft.
	
	Note: The application might require a live internet connection to retrieve aircraft data from the OpenSky API.

	Dependencies:
	1. Java Development Kit (JDK) 8 or higher.
	2. Swing GUI library.
	3. OpenSky API library.

	Author:
	The FlyR Flight Route Planner application was developed by Jeffrey as a project for ICS4U1.

 */

package controller;

import org.opensky.api.OpenSkyApi;
import org.opensky.model.OpenSkyStates;
import org.opensky.model.StateVector;

import model.Waypoint;

import org.opensky.model.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FlightRoutePlanner {

	// Create an instance of OpenSkyApi
	OpenSkyApi openSkyApi = new OpenSkyApi();

	public static List<Waypoint> getSafeRoute(OpenSkyApi openSkyApi, double userLongitude, double userLatitude,
			double destLongitude, double destLatitude, double droneSpeed, double safeDistance) throws IOException {
		// Get the current states of aircraft
		OpenSkyStates states = openSkyApi.getStates(0, null);
		List<StateVector> aircraftStates = (List<StateVector>) states.getStates();

		// Calculate the distance between the user and destination
		double distanceToDestination = calculateDistance(userLatitude, userLongitude, destLatitude, destLongitude);

		// Calculate the time taken to reach the destination by the drone
		double timeToDestination = distanceToDestination / droneSpeed;

		// Create a list to store the waypoints of the route
		List<Waypoint> route = new ArrayList<>();

		// Iterate over the aircraft states and calculate the safe waypoints
		for (StateVector aircraftState : aircraftStates) {
			if (aircraftState.getLatitude() != null && aircraftState.getLongitude() != null) {
				// Get the latitude and longitude of the aircraft
				double aircraftLatitude = aircraftState.getLatitude();
				double aircraftLongitude = aircraftState.getLongitude();

				// Calculate the distance between the user and aircraft
				double distanceToAircraft = calculateDistance(userLatitude, userLongitude, aircraftLatitude,
						aircraftLongitude);

				// Calculate the time taken to reach the aircraft by the drone
				double timeToAircraft = distanceToAircraft / droneSpeed;

				// Calculate the safe distance from the aircraft
				double safeDistanceFromAircraft = (timeToAircraft / timeToDestination) * distanceToDestination
						+ safeDistance;

				// If the distance to the aircraft is greater than the safe distance, add it as
				// a waypoint
				if (distanceToAircraft > safeDistanceFromAircraft) {
					// Calculate the direction from the user to the waypoint
					String direction = calculateDirection(userLatitude, userLongitude, aircraftLatitude,
							aircraftLongitude);

					// Calculate the heading from the user to the waypoint in degrees
					double heading = calculateHeading(userLatitude, userLongitude, aircraftLatitude, aircraftLongitude);

					// Calculate the distance from the user to the waypoint
					double distanceToWaypoint = distanceToAircraft - safeDistanceFromAircraft;

					// Calculate the time taken to reach the waypoint by the drone
					double timeToWaypoint = distanceToWaypoint / droneSpeed;

					// Create the waypoint and add it to the route
					Waypoint waypoint = new Waypoint(direction, heading, distanceToWaypoint, timeToWaypoint);
					route.add(waypoint);
				}
			}
		}

		// Add the destination waypoint to the route
		String finalDirection = calculateDirection(userLatitude, userLongitude, destLatitude, destLongitude);
		double finalHeading = calculateHeading(userLatitude, userLongitude, destLatitude, destLongitude);
		Waypoint destinationWaypoint = new Waypoint(finalDirection, finalHeading, distanceToDestination,
				timeToDestination);
		route.add(destinationWaypoint);

		return route;
	}

	private static double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
		// Implementation of Haversine formula to calculate the distance between two
		// points
		double dLat = Math.toRadians(lat2 - lat1);
		double dLon = Math.toRadians(lon2 - lon1);
		double a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(Math.toRadians(lat1))
				* Math.cos(Math.toRadians(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
		double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
		double distance = 6371 * c * 1000; // Earth's radius in meters
		return distance;
	}

	private static String calculateDirection(double lat1, double lon1, double lat2, double lon2) {
		// Calculate the direction from the first point to the second point
		double dLat = lat2 - lat1;
		double dLon = lon2 - lon1;
		String direction;

		if (Math.abs(dLat) >= Math.abs(dLon)) {
			if (dLat > 0)
				direction = "north";
			else
				direction = "south";
		} else {
			if (dLon > 0)
				direction = "east";
			else
				direction = "west";
		}

		return direction;
	}

	private static double calculateHeading(double lat1, double lon1, double lat2, double lon2) {
		// Calculate the heading in degrees from the first point to the second point
		double dLat = lat2 - lat1;
		double dLon = lon2 - lon1;
		double heading = Math.toDegrees(Math.atan2(dLat, dLon));
		if (heading < 0) {
			heading += 360;
		}
		return heading;
	}

	private static void printRoute(List<Waypoint> route, double droneLatitude, double droneLongitude,
			double destinationLatitude, double destinationLongitude) {
		System.out.println("Start from current location:");
		System.out.printf("Latitude: %.4f, Longitude: %.4f%n", droneLatitude, droneLongitude);
		System.out.println("--------------------------------------------------");

		double totalDistance = calculateDistance(droneLatitude, droneLongitude, destinationLatitude,
				destinationLongitude);

		for (int i = 0; i < route.size(); i++) {
			Waypoint waypoint = route.get(i);
			String direction = waypoint.getDirection();
			double heading = waypoint.getHeading();
			double distance = waypoint.getDistance();
			double time = waypoint.getTime();

			System.out.printf("Step %d: Travel %s (Heading: %.2f°) %.2fm for %.2f seconds%n", (i + 1), direction,
					heading, distance, time);

			if (i < route.size() - 1) {
				// Calculate the fraction of total distance covered at this step
				double fraction = distance / totalDistance;

				// Calculate the intermediate latitude and longitude based on the fraction
				double intermediateLatitude = droneLatitude + fraction * (destinationLatitude - droneLatitude);
				double intermediateLongitude = droneLongitude + fraction * (destinationLongitude - droneLongitude);

				System.out.printf("Intermediate Waypoint %d:%n", (i + 1));
				System.out.printf("Latitude: %.4f, Longitude: %.4f%n", intermediateLatitude, intermediateLongitude);
				System.out.println("--------------------------------------------------");
			}
		}

		System.out.println("Destination reached!");
		System.out.printf("Latitude: %.4f, Longitude: %.4f%n", destinationLatitude, destinationLongitude);
	}

}
