/**
 * Overview:
	Starts the application
	
	Author:
	The application was developed by Jeffrey as a project for ICS4U1.

 */


package application;

//imports
import java.awt.EventQueue;
import view.WelcomePage;

public class FlyRApplication {
	
	// Launch Application
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					WelcomePage frame = new WelcomePage();
					frame.setLocationRelativeTo(null); // Center the frame on the screen
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}







